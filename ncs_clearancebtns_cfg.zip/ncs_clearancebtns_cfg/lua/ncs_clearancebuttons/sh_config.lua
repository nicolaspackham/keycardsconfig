--[[--------------------------------------------]]--
-- Clearance Levels, add as many as you want. 
-- It will automatically create new KeyCard sweps for you to use.
--[[--------------------------------------------]]--

NCS_CLEARANCE.CONFIG.clearanceLevels = {
    [1] = {
        Name = "Clearance Level #1",
    },
    [2] = {
        Name = "Clearance Level #2",
    },
    [3] = {
        Name = "Clearance Level #3",
    },
    [4] = {
        Name = "Clearance Level #4",
    },
    [5] = {
        Name = "Clearance Level #5",
    },
}

--[[--------------------------------------------]]--
-- Time that a door is left unlocked for.
--[[--------------------------------------------]]--

NCS_CLEARANCE.CONFIG.unlockTime = 5

--[[--------------------------------------------]]--
-- Console Health Until Destroyed, or false for no health.
--[[--------------------------------------------]]--

NCS_CLEARANCE.CONFIG.healthValue = false
--NCS_CLEARANCE.CONFIG.healthValue = 500

--[[--------------------------------------------]]--
-- Distance that visuals will display from the console.
--[[--------------------------------------------]]--

NCS_CLEARANCE.CONFIG.visualsDistance = 6

--[[--------------------------------------------]]--
-- Time until a hacking can be completed on a console.
--[[--------------------------------------------]]--

NCS_CLEARANCE.CONFIG.hackingTime = 30

--[[--------------------------------------------]]--
-- Distance that a hack can be completed from the console without cancelling. 
--[[--------------------------------------------]]--

NCS_CLEARANCE.CONFIG.hackingDistance = 6

--[[--------------------------------------------]]--
-- Classes to be considered as doors, probably don't want to change this.
--[[--------------------------------------------]]--

NCS_CLEARANCE.CONFIG.doorClasses = {
    ["func_door"] = true,
	["func_door_rotating"] = true,
	["func_movelinear"] = true,
}

--[[--------------------------------------------]]--
-- Addons language, use the provided language file to create your own.
--[[--------------------------------------------]]--

NCS_CLEARANCE.CONFIG.LANG = "en"