NCS_CLEARANCE.AddLang("en", {
    grantedLabel = "GRANTED",
    bruteForcingLabel = "BRUTEFORCING",
    enterKeycardLabel = "ENTER KEYCARD",
})